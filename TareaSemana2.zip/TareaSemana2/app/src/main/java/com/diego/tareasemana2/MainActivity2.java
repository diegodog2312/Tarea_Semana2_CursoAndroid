package com.diego.tareasemana2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private TextView tvNombre;
    private TextView tvFecha;
    private TextView tvTelefono;
    private TextView tvEmail;
    private TextView tvContacto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tvNombre = findViewById(R.id.tvNombre);
        tvFecha = findViewById(R.id.tvFecha);
        tvTelefono = findViewById(R.id.tvTelefono);
        tvEmail = findViewById(R.id.tvEmail);
        tvContacto = findViewById(R.id.tvContacto);

        tvNombre.setText(getIntent().getStringExtra("nombre"));
        tvFecha.setText("Fecha de nacimiento: "+getIntent().getStringExtra("fecha"));
        tvTelefono.setText("Tel. "+getIntent().getStringExtra("telefono"));
        tvEmail.setText("Email: "+getIntent().getStringExtra("email"));
        tvContacto.setText("Descripcion: "+getIntent().getStringExtra("contacto"));
    }

    //Metodo Editar Datos
    public void Editar(View view){
        finish();
    }
}